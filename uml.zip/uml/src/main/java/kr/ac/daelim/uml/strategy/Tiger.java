package kr.ac.daelim.uml.strategy;

public class Tiger extends Animal {
	IFly fly;
	ICry cry;
	public Tiger() {
		cry = new TigerCry();
		fly = new FlyNoWay();
	}
	public void performCry() {
		cry.cry();
		System.out.println("호랑이");
		
	}
	
	public void performFly() {
		fly.fly();
		System.out.println("어흥");
	}
	}

