package kr.ac.daelim.uml;

public class Medic  extends Unit {
	
	private void Move()
	{
	 System.out.println("메딕이 움직인다.");
	}
	public void Healing()
	{
		 System.out.println("메딕이 치료한다.");
	}
	public void UnderAttack(Charactor charactor)
	{
		 System.out.println("메딕이 공격받는다.");
	}
	public static void main( String[] args )
    {
        Medic m2 = new Medic();
        
    }
}

