package kr.ac.daelim.uml;

public class Marine extends Unit {
	private String name;
	public int health;
	protected int attackPower;
	void Move()
	{
	 System.out.println("마린이 움직인다.");
	}
	public void Attack()
	{
		 System.out.println("마린이 공격한다.");
	}
	public void UnderAttack(Charactor charactor)
	{
		 System.out.println("마린이 공격받는다.");
	}
	public static void main( String[] args )
    {
        Marine m = new Marine();
        m.Attack();
    }
}
 