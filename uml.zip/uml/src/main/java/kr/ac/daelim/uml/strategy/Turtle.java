package kr.ac.daelim.uml.strategy;

public class Turtle extends Animal {
		IFly fly;
		ICry cry;
		public Turtle() {
			cry = new CryNoway();
			fly = new FlyNoWay();
		}
		public void performCry() {
			cry.cry();
			System.out.println("그북이");
			
		}
		
		public void performFly() {
			fly.fly();
			System.out.println("..");
		}
		public void display() {
			System.out.println("거부기");
			
		}
		public void move() {
			System.out.println("그북기 무빙");
		}
		
}
