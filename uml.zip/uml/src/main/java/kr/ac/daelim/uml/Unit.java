package kr.ac.daelim.uml;

public class Unit {
	private String name;
	public int health;
	
	
	void Move() {
		System.out.println("유닛이 움직인다");
	}
	
	public void UnderAttack(Charactor charactor)
	{
		System.out.println("유닛이 공격을 받는다");
	}
}
