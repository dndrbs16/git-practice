package kr.ac.daelim.uml.strategy;

public interface ICry {
	public void cry();
		
	}

