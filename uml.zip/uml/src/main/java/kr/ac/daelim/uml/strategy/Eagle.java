package kr.ac.daelim.uml.strategy;

public class Eagle extends Animal {
	IFly fly;
	ICry cry;
	Eagle() {
		cry = new BirdCry();
		fly = new FlyNoWay();
	}
	public void performCry() {
		cry.cry();
		System.out.println("독수리");
		
	}
	
	public void performFly() {
		fly.fly();
		System.out.println("끼룩끼룩");
	}
	
	public void display() {
		System.out.println("독수리");
		
	}
	public void move() {
		System.out.println("독수리 무빙");
		
	}
	}
