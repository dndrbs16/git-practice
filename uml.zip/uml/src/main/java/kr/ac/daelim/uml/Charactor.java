package kr.ac.daelim.uml;

public class Charactor {

}
