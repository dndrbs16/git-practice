package kr.ac.daelim.uml.strategy;

public class TigerCry implements ICry{

	public void cry() {
		System.out.println("짹쨲!!");
	}
}